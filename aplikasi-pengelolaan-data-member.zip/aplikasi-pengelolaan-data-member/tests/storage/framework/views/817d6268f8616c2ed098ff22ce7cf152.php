<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>KTA A5 Landscape</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        @page {
            size: 794px 559px;
            margin: 0;
        }

        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            font-size: 12px;
            color: #000;
        }

        .kta {
            position: relative;
            width: 794px;
            height: 559px;
            overflow: hidden;
        }

        .background-img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: 0;
        }

        .content {
            position: absolute;
            top: 30px;
            left: 100px;
            right: 130px;
            bottom: 30px;
            z-index: 1;
        }

        .header {
            text-align: center;
            font-size: 18px;
            font-weight: 700;
            line-height: 1.4;
            margin-bottom: 6px;
        }

        .subheader {
            text-align: center;
            font-size: 13px;
            font-style: italic;
            margin-bottom: 20px;
            font-weight: 400;
        }

        .data {
            margin-top: 10px;
        }

        .data td {
            padding: 3px 6px;
            font-size: 12px;
        }

        .data td:first-child {
            width: 140px;
            font-weight: 600;
        }

        .data td:nth-child(2) {
            width: 10px;
        }

        .photo {
            position: absolute;
            top: 150px;
            right: 100px;
            width: 85px;
            height: 105px;
            background-color: #f0f0f0;
            border: 2px solid #000;
            z-index: 2;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            text-align: center;
        }

        .photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="kta">
        
        <img src="data:image/png;base64,<?php echo e($kop); ?>" alt="Background" class="background-img" />

        
        <div class="content">
            <div class="header">
                KARTU ANGGOTA<br>
                KOPERASI MERAH PUTIH DESA CANTEL<br>
                KECAMATAN PITU, NGAWI
            </div>
            <div class="subheader">
                Merah Putih, Mandiri dan Sejahtera
            </div>

            <table class="data">
                <tr>
                    <td>Category</td>
                    <td>:</td>
                    <td><?php echo e($member->category->name); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e(date('F j, Y', strtotime($member->birt_date))); ?></td>
                </tr>
                <tr>
                    <td>Full Name</td>
                    <td>:</td>
                    <td><?php echo e($member->full_name); ?></td>
                </tr>
                    <tr>
                    <td>NIK</td>
                    <td>:</td>
                    <td><?php echo e($member->nik); ?></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td><?php echo e($member->gender); ?></td>
                </tr>
                <tr>
                    <td>Address</td>
                    <td>:</td>
                    <td><?php echo e($member->address); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo e($member->email); ?></td>
                </tr>
                <tr>
                    <td>Phone Number</td>
                    <td>:</td>
                    <td><?php echo e($member->phone_number); ?></td>
                </tr>
            </table>
        </div>

        
        <div class="photo">
            <?php if($photoBase64): ?>
                <img src="<?php echo e($photoBase64); ?>" alt="Foto Anggota">
            <?php else: ?>
                Foto Tidak<br>Tersedia
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\3.BUWONO\Dokumen\kuliah\SEMESTER 7\KKN\proker\aplikasi-pengelolaan-data-member\aplikasi-pengelolaan-data-member\resources\views/members/kta.blade.php ENDPATH**/ ?>
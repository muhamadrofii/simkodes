<div class="d-flex flex-column flex-lg-row mb-4">
    
    <div class="flex-grow-1">
        <h3><?php echo e($slot); ?></h3>
    </div>
    
    <div class="pt-lg-1">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="https://pustakakoding.com/" class="text-dark text-decoration-none">
                        <i class="ti ti-home fs-5"></i>
                    </a>
                </li>
                <li class="breadcrumb-item" aria-current="page">
                    <?php echo e($slot); ?>

                </li>
            </ol>
        </nav>
    </div>
</div><?php /**PATH D:\laragon\www\Pustaka-Koding\Project-Laravel\Laravel-11\aplikasi-pengelolaan-data-member\resources\views/components/page-title.blade.php ENDPATH**/ ?>